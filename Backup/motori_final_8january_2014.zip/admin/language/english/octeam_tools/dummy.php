<?php
// Heading
$_['heading_title']           = 'Dummy Tool';
$_['version']                 = ' <span style="color:#666; font-size: 11px; font-weight:normal;">(version: %s)</span>';

// Text 
$_['text_octeam_toolset']     = 'Tools';
$_['text_success']            = 'Success: You have modified "Dummy" tool!';
$_['text_dummy']              = '<a onclick="window.open(\'http://myopencart.ru/\');"><img src="view/image/octeam/octeam.png" alt="OC Team" title="OC Team" style="border: 1px solid #EEEEEE;" height="25px" /><img src="view/image/octeam/tool/dummy.png" alt="Dummy" title="Dummy" style="border: 1px solid #EEEEEE;" height="25px" /></a>';
$_['text_description']        = 'This is a dummy description of dummy tool. It shoud NOT be too long.';

// Error
$_['error_permission']        = 'Warning: You do not have permission to modify tool "Dummy"!';

?>