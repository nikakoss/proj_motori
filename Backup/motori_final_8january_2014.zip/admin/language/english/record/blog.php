<?php
$_['text_january'] = "January";
$_['text_february'] = "February";
$_['text_march'] = "March";
$_['text_april'] = "April";
$_['text_may'] = "may";
$_['text_june'] = "June";
$_['text_july'] = "July";
$_['text_august'] = "August";
$_['text_september'] = "September";
$_['text_october'] = "October";
$_['text_november'] = "November";
$_['text_december'] = "December";
$_['text_today'] = "Today";
$_['text_date'] = ' d M Y';
$_['text_hours'] = " H:i:s";
?>