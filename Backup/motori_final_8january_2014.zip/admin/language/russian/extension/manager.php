<?php
// Heading
$_['heading_title']    = 'Менеджер расширений';

// Text
$_['text_success']     = 'Расширение успешно установлено!';

// Error
$_['error_permission'] = 'У Вас нет прав для модификации расширений!';
$_['error_upload']     = 'Требуется указать файл!';
$_['error_filetype']   = 'Неверный тип файла!';
?>