<?php
$_['text_january']         = "января";
$_['text_february']        = "февраля";
$_['text_march']           = "марта";
$_['text_april']           = "апреля";
$_['text_may']             = "мая";
$_['text_june']            = "июня";
$_['text_july']            = "июля";
$_['text_august']          = "августа";
$_['text_september']       = "сентября";
$_['text_october']         = "октября";
$_['text_november']        = "ноября";
$_['text_december']        = "декабря";
$_['text_today']           = "Сегодня";
$_['text_date']            = "d M Y";
$_['text_hours']           = " в H:i:s";
?>